--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE perpussmkn2;
--
-- Name: perpussmkn2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE perpussmkn2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_Indonesia.1252';


ALTER DATABASE perpussmkn2 OWNER TO postgres;

\connect perpussmkn2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: perpussmkn2; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA perpussmkn2;


ALTER SCHEMA perpussmkn2 OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tabel_akses; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_akses (
    kode_akses character varying NOT NULL,
    level_akses character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_akses OWNER TO postgres;

--
-- Name: tabel_anggota; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_anggota (
    id_anggota character varying NOT NULL,
    no_registrasi character varying NOT NULL,
    id_jurusan character varying NOT NULL,
    nama_anggota character varying(99) NOT NULL,
    no_induk integer NOT NULL
);


ALTER TABLE perpussmkn2.tabel_anggota OWNER TO postgres;

--
-- Name: tabel_anggota_id_anggota_seq; Type: SEQUENCE; Schema: perpussmkn2; Owner: postgres
--

CREATE SEQUENCE perpussmkn2.tabel_anggota_id_anggota_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perpussmkn2.tabel_anggota_id_anggota_seq OWNER TO postgres;

--
-- Name: tabel_anggota_id_anggota_seq; Type: SEQUENCE OWNED BY; Schema: perpussmkn2; Owner: postgres
--

ALTER SEQUENCE perpussmkn2.tabel_anggota_id_anggota_seq OWNED BY perpussmkn2.tabel_anggota.id_anggota;


--
-- Name: tabel_buku; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_buku (
    id_buku character varying NOT NULL,
    id_perolehan character varying NOT NULL,
    id_status character varying NOT NULL,
    id_penerbit character varying NOT NULL,
    id_subyek character varying NOT NULL,
    id_jenis character varying NOT NULL,
    judul_buku character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_buku OWNER TO postgres;

--
-- Name: tabel_buku_id_buku_seq; Type: SEQUENCE; Schema: perpussmkn2; Owner: postgres
--

CREATE SEQUENCE perpussmkn2.tabel_buku_id_buku_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perpussmkn2.tabel_buku_id_buku_seq OWNER TO postgres;

--
-- Name: tabel_buku_id_buku_seq; Type: SEQUENCE OWNED BY; Schema: perpussmkn2; Owner: postgres
--

ALTER SEQUENCE perpussmkn2.tabel_buku_id_buku_seq OWNED BY perpussmkn2.tabel_buku.id_buku;


--
-- Name: tabel_denda; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_denda (
    id_denda character varying NOT NULL,
    denda integer NOT NULL
);


ALTER TABLE perpussmkn2.tabel_denda OWNER TO postgres;

--
-- Name: tabel_detail_peminjaman; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_detail_peminjaman (
    id_peminjaman character varying NOT NULL,
    id_buku character varying NOT NULL,
    tanggal_pinjam character varying NOT NULL,
    tanggal_pengembalian character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_detail_peminjaman OWNER TO postgres;

--
-- Name: tabel_detail_pengarang; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_detail_pengarang (
    id_buku character varying NOT NULL,
    id_pengarang character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_detail_pengarang OWNER TO postgres;

--
-- Name: tabel_detail_pengembalian; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_detail_pengembalian (
    id_pengembalian character varying NOT NULL,
    id_keterangan character varying NOT NULL,
    tanggal_dikembalikan character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_detail_pengembalian OWNER TO postgres;

--
-- Name: tabel_jenis; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_jenis (
    id_jenis character varying NOT NULL,
    jenis_koleksi character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_jenis OWNER TO postgres;

--
-- Name: tabel_jurusan; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_jurusan (
    id_jurusan character varying NOT NULL,
    jurusan character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_jurusan OWNER TO postgres;

--
-- Name: tabel_keterangan; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_keterangan (
    id_keterangan character varying NOT NULL,
    id_denda character varying NOT NULL,
    keterangan character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_keterangan OWNER TO postgres;

--
-- Name: tabel_peminjaman; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_peminjaman (
    id_peminjaman character varying NOT NULL,
    id_anggota character varying NOT NULL,
    id_user character varying NOT NULL,
    id_buku character varying(100)
);


ALTER TABLE perpussmkn2.tabel_peminjaman OWNER TO postgres;

--
-- Name: tabel_peminjaman_id_peminjaman_seq; Type: SEQUENCE; Schema: perpussmkn2; Owner: postgres
--

CREATE SEQUENCE perpussmkn2.tabel_peminjaman_id_peminjaman_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perpussmkn2.tabel_peminjaman_id_peminjaman_seq OWNER TO postgres;

--
-- Name: tabel_peminjaman_id_peminjaman_seq; Type: SEQUENCE OWNED BY; Schema: perpussmkn2; Owner: postgres
--

ALTER SEQUENCE perpussmkn2.tabel_peminjaman_id_peminjaman_seq OWNED BY perpussmkn2.tabel_peminjaman.id_peminjaman;


--
-- Name: tabel_penerbit; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_penerbit (
    id_penerbit character varying NOT NULL,
    nama_penerbit character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_penerbit OWNER TO postgres;

--
-- Name: tabel_pengarang; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_pengarang (
    id_pengarang character varying NOT NULL,
    nama_pengarang character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_pengarang OWNER TO postgres;

--
-- Name: tabel_pengembalian; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_pengembalian (
    id_pengembalian character varying NOT NULL,
    id_user character varying NOT NULL,
    id_peminjaman character varying NOT NULL,
    id_anggota character varying(100)
);


ALTER TABLE perpussmkn2.tabel_pengembalian OWNER TO postgres;

--
-- Name: tabel_pengembalian_id_pengembalian_seq; Type: SEQUENCE; Schema: perpussmkn2; Owner: postgres
--

CREATE SEQUENCE perpussmkn2.tabel_pengembalian_id_pengembalian_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perpussmkn2.tabel_pengembalian_id_pengembalian_seq OWNER TO postgres;

--
-- Name: tabel_pengembalian_id_pengembalian_seq; Type: SEQUENCE OWNED BY; Schema: perpussmkn2; Owner: postgres
--

ALTER SEQUENCE perpussmkn2.tabel_pengembalian_id_pengembalian_seq OWNED BY perpussmkn2.tabel_pengembalian.id_pengembalian;


--
-- Name: tabel_perolehan; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_perolehan (
    id_perolehan character varying NOT NULL,
    perolehan character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_perolehan OWNER TO postgres;

--
-- Name: tabel_registrasi; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_registrasi (
    no_registrasi character varying NOT NULL,
    tanggal_registrasi character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_registrasi OWNER TO postgres;

--
-- Name: tabel_registrasi_no_registrasi_seq_1; Type: SEQUENCE; Schema: perpussmkn2; Owner: postgres
--

CREATE SEQUENCE perpussmkn2.tabel_registrasi_no_registrasi_seq_1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE perpussmkn2.tabel_registrasi_no_registrasi_seq_1 OWNER TO postgres;

--
-- Name: tabel_registrasi_no_registrasi_seq_1; Type: SEQUENCE OWNED BY; Schema: perpussmkn2; Owner: postgres
--

ALTER SEQUENCE perpussmkn2.tabel_registrasi_no_registrasi_seq_1 OWNED BY perpussmkn2.tabel_registrasi.no_registrasi;


--
-- Name: tabel_status; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_status (
    id_status character varying NOT NULL,
    status character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_status OWNER TO postgres;

--
-- Name: tabel_subyek; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_subyek (
    id_subyek character varying NOT NULL,
    subyek_buku character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_subyek OWNER TO postgres;

--
-- Name: tabel_user; Type: TABLE; Schema: perpussmkn2; Owner: postgres
--

CREATE TABLE perpussmkn2.tabel_user (
    id_user character varying NOT NULL,
    kode_akses character varying NOT NULL,
    pass_user character varying NOT NULL,
    nama_user character varying NOT NULL,
    telepon_user character varying NOT NULL,
    alamat_user character varying NOT NULL
);


ALTER TABLE perpussmkn2.tabel_user OWNER TO postgres;

--
-- Name: tabel_anggota id_anggota; Type: DEFAULT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_anggota ALTER COLUMN id_anggota SET DEFAULT nextval('perpussmkn2.tabel_anggota_id_anggota_seq'::regclass);


--
-- Name: tabel_buku id_buku; Type: DEFAULT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku ALTER COLUMN id_buku SET DEFAULT nextval('perpussmkn2.tabel_buku_id_buku_seq'::regclass);


--
-- Name: tabel_peminjaman id_peminjaman; Type: DEFAULT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_peminjaman ALTER COLUMN id_peminjaman SET DEFAULT nextval('perpussmkn2.tabel_peminjaman_id_peminjaman_seq'::regclass);


--
-- Name: tabel_pengembalian id_pengembalian; Type: DEFAULT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_pengembalian ALTER COLUMN id_pengembalian SET DEFAULT nextval('perpussmkn2.tabel_pengembalian_id_pengembalian_seq'::regclass);


--
-- Name: tabel_registrasi no_registrasi; Type: DEFAULT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_registrasi ALTER COLUMN no_registrasi SET DEFAULT nextval('perpussmkn2.tabel_registrasi_no_registrasi_seq_1'::regclass);


--
-- Data for Name: tabel_akses; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_akses (kode_akses, level_akses) FROM stdin;
\.
COPY perpussmkn2.tabel_akses (kode_akses, level_akses) FROM '$$PATH$$/3446.dat';

--
-- Data for Name: tabel_anggota; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_anggota (id_anggota, no_registrasi, id_jurusan, nama_anggota, no_induk) FROM stdin;
\.
COPY perpussmkn2.tabel_anggota (id_anggota, no_registrasi, id_jurusan, nama_anggota, no_induk) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: tabel_buku; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_buku (id_buku, id_perolehan, id_status, id_penerbit, id_subyek, id_jenis, judul_buku) FROM stdin;
\.
COPY perpussmkn2.tabel_buku (id_buku, id_perolehan, id_status, id_penerbit, id_subyek, id_jenis, judul_buku) FROM '$$PATH$$/3449.dat';

--
-- Data for Name: tabel_denda; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_denda (id_denda, denda) FROM stdin;
\.
COPY perpussmkn2.tabel_denda (id_denda, denda) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: tabel_detail_peminjaman; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_detail_peminjaman (id_peminjaman, id_buku, tanggal_pinjam, tanggal_pengembalian) FROM stdin;
\.
COPY perpussmkn2.tabel_detail_peminjaman (id_peminjaman, id_buku, tanggal_pinjam, tanggal_pengembalian) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: tabel_detail_pengarang; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_detail_pengarang (id_buku, id_pengarang) FROM stdin;
\.
COPY perpussmkn2.tabel_detail_pengarang (id_buku, id_pengarang) FROM '$$PATH$$/3453.dat';

--
-- Data for Name: tabel_detail_pengembalian; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_detail_pengembalian (id_pengembalian, id_keterangan, tanggal_dikembalikan) FROM stdin;
\.
COPY perpussmkn2.tabel_detail_pengembalian (id_pengembalian, id_keterangan, tanggal_dikembalikan) FROM '$$PATH$$/3454.dat';

--
-- Data for Name: tabel_jenis; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_jenis (id_jenis, jenis_koleksi) FROM stdin;
\.
COPY perpussmkn2.tabel_jenis (id_jenis, jenis_koleksi) FROM '$$PATH$$/3455.dat';

--
-- Data for Name: tabel_jurusan; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_jurusan (id_jurusan, jurusan) FROM stdin;
\.
COPY perpussmkn2.tabel_jurusan (id_jurusan, jurusan) FROM '$$PATH$$/3456.dat';

--
-- Data for Name: tabel_keterangan; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_keterangan (id_keterangan, id_denda, keterangan) FROM stdin;
\.
COPY perpussmkn2.tabel_keterangan (id_keterangan, id_denda, keterangan) FROM '$$PATH$$/3457.dat';

--
-- Data for Name: tabel_peminjaman; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_peminjaman (id_peminjaman, id_anggota, id_user, id_buku) FROM stdin;
\.
COPY perpussmkn2.tabel_peminjaman (id_peminjaman, id_anggota, id_user, id_buku) FROM '$$PATH$$/3458.dat';

--
-- Data for Name: tabel_penerbit; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_penerbit (id_penerbit, nama_penerbit) FROM stdin;
\.
COPY perpussmkn2.tabel_penerbit (id_penerbit, nama_penerbit) FROM '$$PATH$$/3460.dat';

--
-- Data for Name: tabel_pengarang; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_pengarang (id_pengarang, nama_pengarang) FROM stdin;
\.
COPY perpussmkn2.tabel_pengarang (id_pengarang, nama_pengarang) FROM '$$PATH$$/3461.dat';

--
-- Data for Name: tabel_pengembalian; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_pengembalian (id_pengembalian, id_user, id_peminjaman, id_anggota) FROM stdin;
\.
COPY perpussmkn2.tabel_pengembalian (id_pengembalian, id_user, id_peminjaman, id_anggota) FROM '$$PATH$$/3462.dat';

--
-- Data for Name: tabel_perolehan; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_perolehan (id_perolehan, perolehan) FROM stdin;
\.
COPY perpussmkn2.tabel_perolehan (id_perolehan, perolehan) FROM '$$PATH$$/3464.dat';

--
-- Data for Name: tabel_registrasi; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_registrasi (no_registrasi, tanggal_registrasi) FROM stdin;
\.
COPY perpussmkn2.tabel_registrasi (no_registrasi, tanggal_registrasi) FROM '$$PATH$$/3465.dat';

--
-- Data for Name: tabel_status; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_status (id_status, status) FROM stdin;
\.
COPY perpussmkn2.tabel_status (id_status, status) FROM '$$PATH$$/3467.dat';

--
-- Data for Name: tabel_subyek; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_subyek (id_subyek, subyek_buku) FROM stdin;
\.
COPY perpussmkn2.tabel_subyek (id_subyek, subyek_buku) FROM '$$PATH$$/3468.dat';

--
-- Data for Name: tabel_user; Type: TABLE DATA; Schema: perpussmkn2; Owner: postgres
--

COPY perpussmkn2.tabel_user (id_user, kode_akses, pass_user, nama_user, telepon_user, alamat_user) FROM stdin;
\.
COPY perpussmkn2.tabel_user (id_user, kode_akses, pass_user, nama_user, telepon_user, alamat_user) FROM '$$PATH$$/3469.dat';

--
-- Name: tabel_anggota_id_anggota_seq; Type: SEQUENCE SET; Schema: perpussmkn2; Owner: postgres
--

SELECT pg_catalog.setval('perpussmkn2.tabel_anggota_id_anggota_seq', 1, false);


--
-- Name: tabel_buku_id_buku_seq; Type: SEQUENCE SET; Schema: perpussmkn2; Owner: postgres
--

SELECT pg_catalog.setval('perpussmkn2.tabel_buku_id_buku_seq', 1, false);


--
-- Name: tabel_peminjaman_id_peminjaman_seq; Type: SEQUENCE SET; Schema: perpussmkn2; Owner: postgres
--

SELECT pg_catalog.setval('perpussmkn2.tabel_peminjaman_id_peminjaman_seq', 1, false);


--
-- Name: tabel_pengembalian_id_pengembalian_seq; Type: SEQUENCE SET; Schema: perpussmkn2; Owner: postgres
--

SELECT pg_catalog.setval('perpussmkn2.tabel_pengembalian_id_pengembalian_seq', 1, false);


--
-- Name: tabel_registrasi_no_registrasi_seq_1; Type: SEQUENCE SET; Schema: perpussmkn2; Owner: postgres
--

SELECT pg_catalog.setval('perpussmkn2.tabel_registrasi_no_registrasi_seq_1', 1, false);


--
-- Name: tabel_akses tabel_akses_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_akses
    ADD CONSTRAINT tabel_akses_pk PRIMARY KEY (kode_akses);


--
-- Name: tabel_anggota tabel_anggota_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_anggota
    ADD CONSTRAINT tabel_anggota_pk PRIMARY KEY (id_anggota);


--
-- Name: tabel_buku tabel_buku_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku
    ADD CONSTRAINT tabel_buku_pk PRIMARY KEY (id_buku);


--
-- Name: tabel_denda tabel_denda_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_denda
    ADD CONSTRAINT tabel_denda_pk PRIMARY KEY (id_denda);


--
-- Name: tabel_detail_pengembalian tabel_detail_peminjaman_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_pengembalian
    ADD CONSTRAINT tabel_detail_peminjaman_pk PRIMARY KEY (id_pengembalian);


--
-- Name: tabel_detail_pengarang tabel_detail_pengarang_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_pengarang
    ADD CONSTRAINT tabel_detail_pengarang_pk PRIMARY KEY (id_buku, id_pengarang);


--
-- Name: tabel_jenis tabel_jenis_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_jenis
    ADD CONSTRAINT tabel_jenis_pk PRIMARY KEY (id_jenis);


--
-- Name: tabel_jurusan tabel_jurusan_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_jurusan
    ADD CONSTRAINT tabel_jurusan_pk PRIMARY KEY (id_jurusan);


--
-- Name: tabel_keterangan tabel_keterangan_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_keterangan
    ADD CONSTRAINT tabel_keterangan_pk PRIMARY KEY (id_keterangan);


--
-- Name: tabel_peminjaman tabel_peminjaman_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_peminjaman
    ADD CONSTRAINT tabel_peminjaman_pk PRIMARY KEY (id_peminjaman);


--
-- Name: tabel_penerbit tabel_penerbit_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_penerbit
    ADD CONSTRAINT tabel_penerbit_pk PRIMARY KEY (id_penerbit);


--
-- Name: tabel_pengarang tabel_pengarang_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_pengarang
    ADD CONSTRAINT tabel_pengarang_pk PRIMARY KEY (id_pengarang);


--
-- Name: tabel_pengembalian tabel_pengembalian_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_pengembalian
    ADD CONSTRAINT tabel_pengembalian_pk PRIMARY KEY (id_pengembalian);


--
-- Name: tabel_perolehan tabel_perolehan_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_perolehan
    ADD CONSTRAINT tabel_perolehan_pk PRIMARY KEY (id_perolehan);


--
-- Name: tabel_registrasi tabel_registrasi_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_registrasi
    ADD CONSTRAINT tabel_registrasi_pk PRIMARY KEY (no_registrasi);


--
-- Name: tabel_status tabel_status_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_status
    ADD CONSTRAINT tabel_status_pk PRIMARY KEY (id_status);


--
-- Name: tabel_subyek tabel_subyek_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_subyek
    ADD CONSTRAINT tabel_subyek_pk PRIMARY KEY (id_subyek);


--
-- Name: tabel_user tabel_user_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_user
    ADD CONSTRAINT tabel_user_pk PRIMARY KEY (id_user);


--
-- Name: tabel_detail_peminjaman tebel_detail_peminjaman_pk; Type: CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_peminjaman
    ADD CONSTRAINT tebel_detail_peminjaman_pk PRIMARY KEY (id_peminjaman, id_buku);


--
-- Name: id_anggota; Type: INDEX; Schema: perpussmkn2; Owner: postgres
--

CREATE INDEX id_anggota ON perpussmkn2.tabel_pengembalian USING btree (id_anggota);


--
-- Name: id_buku; Type: INDEX; Schema: perpussmkn2; Owner: postgres
--

CREATE INDEX id_buku ON perpussmkn2.tabel_peminjaman USING btree (id_buku);


--
-- Name: tabel_pengembalian id_anggota; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_pengembalian
    ADD CONSTRAINT id_anggota FOREIGN KEY (id_anggota) REFERENCES perpussmkn2.tabel_anggota(id_anggota);


--
-- Name: tabel_peminjaman id_buku; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_peminjaman
    ADD CONSTRAINT id_buku FOREIGN KEY (id_buku) REFERENCES perpussmkn2.tabel_buku(id_buku);


--
-- Name: tabel_user tabel_akses_tabel_user_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_user
    ADD CONSTRAINT tabel_akses_tabel_user_fk FOREIGN KEY (kode_akses) REFERENCES perpussmkn2.tabel_akses(kode_akses);


--
-- Name: tabel_peminjaman tabel_anggota_tabel_peminjaman_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_peminjaman
    ADD CONSTRAINT tabel_anggota_tabel_peminjaman_fk FOREIGN KEY (id_anggota) REFERENCES perpussmkn2.tabel_anggota(id_anggota);


--
-- Name: tabel_detail_pengarang tabel_buku_tabel_detail_pengarang_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_pengarang
    ADD CONSTRAINT tabel_buku_tabel_detail_pengarang_fk FOREIGN KEY (id_buku) REFERENCES perpussmkn2.tabel_buku(id_buku);


--
-- Name: tabel_detail_peminjaman tabel_buku_tebel_detail_peminjaman_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_peminjaman
    ADD CONSTRAINT tabel_buku_tebel_detail_peminjaman_fk FOREIGN KEY (id_buku) REFERENCES perpussmkn2.tabel_buku(id_buku);


--
-- Name: tabel_keterangan tabel_denda_tabel_keterangan_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_keterangan
    ADD CONSTRAINT tabel_denda_tabel_keterangan_fk FOREIGN KEY (id_denda) REFERENCES perpussmkn2.tabel_denda(id_denda);


--
-- Name: tabel_buku tabel_jenis_tabel_buku_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku
    ADD CONSTRAINT tabel_jenis_tabel_buku_fk FOREIGN KEY (id_jenis) REFERENCES perpussmkn2.tabel_jenis(id_jenis);


--
-- Name: tabel_anggota tabel_jurusan_tabel_anggota_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_anggota
    ADD CONSTRAINT tabel_jurusan_tabel_anggota_fk FOREIGN KEY (id_jurusan) REFERENCES perpussmkn2.tabel_jurusan(id_jurusan);


--
-- Name: tabel_detail_pengembalian tabel_keterangan_tabel_detail_peminjaman_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_pengembalian
    ADD CONSTRAINT tabel_keterangan_tabel_detail_peminjaman_fk FOREIGN KEY (id_keterangan) REFERENCES perpussmkn2.tabel_keterangan(id_keterangan);


--
-- Name: tabel_pengembalian tabel_peminjaman_tabel_pengembalian_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_pengembalian
    ADD CONSTRAINT tabel_peminjaman_tabel_pengembalian_fk FOREIGN KEY (id_peminjaman) REFERENCES perpussmkn2.tabel_peminjaman(id_peminjaman);


--
-- Name: tabel_detail_peminjaman tabel_peminjaman_tebel_detail_peminjaman_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_peminjaman
    ADD CONSTRAINT tabel_peminjaman_tebel_detail_peminjaman_fk FOREIGN KEY (id_peminjaman) REFERENCES perpussmkn2.tabel_peminjaman(id_peminjaman);


--
-- Name: tabel_buku tabel_penerbit_tabel_buku_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku
    ADD CONSTRAINT tabel_penerbit_tabel_buku_fk FOREIGN KEY (id_penerbit) REFERENCES perpussmkn2.tabel_penerbit(id_penerbit);


--
-- Name: tabel_detail_pengarang tabel_pengarang_tabel_detail_pengarang_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_pengarang
    ADD CONSTRAINT tabel_pengarang_tabel_detail_pengarang_fk FOREIGN KEY (id_pengarang) REFERENCES perpussmkn2.tabel_pengarang(id_pengarang);


--
-- Name: tabel_detail_pengembalian tabel_pengembalian_tabel_detail_peminjaman_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_detail_pengembalian
    ADD CONSTRAINT tabel_pengembalian_tabel_detail_peminjaman_fk FOREIGN KEY (id_pengembalian) REFERENCES perpussmkn2.tabel_pengembalian(id_pengembalian);


--
-- Name: tabel_buku tabel_perolehan_tabel_buku_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku
    ADD CONSTRAINT tabel_perolehan_tabel_buku_fk FOREIGN KEY (id_perolehan) REFERENCES perpussmkn2.tabel_perolehan(id_perolehan);


--
-- Name: tabel_anggota tabel_registrasi_tabel_anggota_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_anggota
    ADD CONSTRAINT tabel_registrasi_tabel_anggota_fk FOREIGN KEY (no_registrasi) REFERENCES perpussmkn2.tabel_registrasi(no_registrasi);


--
-- Name: tabel_buku tabel_status_tabel_buku_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku
    ADD CONSTRAINT tabel_status_tabel_buku_fk FOREIGN KEY (id_status) REFERENCES perpussmkn2.tabel_status(id_status);


--
-- Name: tabel_buku tabel_subyek_tabel_buku_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_buku
    ADD CONSTRAINT tabel_subyek_tabel_buku_fk FOREIGN KEY (id_subyek) REFERENCES perpussmkn2.tabel_subyek(id_subyek);


--
-- Name: tabel_peminjaman tabel_user_tabel_peminjaman_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_peminjaman
    ADD CONSTRAINT tabel_user_tabel_peminjaman_fk FOREIGN KEY (id_user) REFERENCES perpussmkn2.tabel_user(id_user);


--
-- Name: tabel_pengembalian tabel_user_tabel_pengembalian_fk; Type: FK CONSTRAINT; Schema: perpussmkn2; Owner: postgres
--

ALTER TABLE ONLY perpussmkn2.tabel_pengembalian
    ADD CONSTRAINT tabel_user_tabel_pengembalian_fk FOREIGN KEY (id_user) REFERENCES perpussmkn2.tabel_user(id_user);


--
-- PostgreSQL database dump complete
--

